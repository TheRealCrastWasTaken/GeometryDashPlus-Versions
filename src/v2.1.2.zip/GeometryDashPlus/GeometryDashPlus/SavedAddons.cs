﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using Microsoft.VisualBasic;
using System.Diagnostics;
using System.Reflection;

namespace GeometryDashPlus
{
    public partial class SavedAddons : Form
    {
        public SavedAddons()
        {
            InitializeComponent();

            RefreshAddons();

            Console.WriteLine(Assembly.GetExecutingAssembly().Location); // I forget what this does
        }

        private string selectedAddon = null; // Current Selected Addon
        private readonly string exeUrl = Assembly.GetExecutingAssembly().Location; // Location of the GDP executable

        private void RefreshAddons()
        {
            selectedAddon = null; // Deselects an addon if an addon was selected

            addonsList.Controls.Clear(); // Clears the addons list

            //string[] addons = Directory.GetDirectories(@"C:\GeometryDashPlus\Addons\");
            string[] addons = Directory.GetDirectories(exeUrl + @"\..\..\Addons\"); // Gets all addons

            foreach (string addonDir in addons) // Goes through each addon
            {
                string addonsUrl = exeUrl + @"\..\..\Addons\";
                string addonName = addonDir.Substring(addonsUrl.Length); // Gets the name of the addon
                CreateAddonButton(addonName); // Creates a button specifically for that addon
                Console.WriteLine(addonName); // Debug command lol
            }
        }

        private void AddonButtonPressHandler(object sender, EventArgs e)
        {
            Button btn = (Button)sender; // Gets the button for the addon

            if (selectedAddon != btn.Text) // Is the user not selecting this addon/button?
            {
                selectedAddon = btn.Text; // Select the addon
                selectedAddonLabel.Text = selectedAddon; // Set the selected addon label to the selected addon's name
            } else
            {
                selectedAddon = null; // Deselect the addon
                selectedAddonLabel.Text = "-"; // Set the selected addon label to -
            }
        }

        private async void LoadAddon()
        {
            //CopyFilesRecursively(@"C:\GeometryDashPlus\Addons\" + selectedAddon, @"E:\Steam Develop\steamapps\common\Geometry Dash\Resources\");
            await Task.Run(() => CopyFilesRecursively(exeUrl + @"\..\..\Addons\" + selectedAddon, exeUrl + @"\..\..\..\")); // Smooooooooth
        }

        private static async void CopyFilesRecursively(string sourcePath, string targetPath) // I copied this code
        { 
            await Task.Run(() =>
            {
                //Now Create all of the directories
                foreach (string dirPath in Directory.GetDirectories(sourcePath, " * ", SearchOption.AllDirectories))
                {
                    Directory.CreateDirectory(dirPath.Replace(sourcePath, targetPath));
                }

                //Copy all the files & Replaces any files with the same name
                foreach (string newPath in Directory.GetFiles(sourcePath, "*.*", SearchOption.AllDirectories))
                {
                    File.Copy(newPath, newPath.Replace(sourcePath, targetPath), true);
                }
            });
        }

        private Button CreateAddonButton(string addonName) // Creates an addon button
        {
            Button myButton = new Button() // The feeling that I spent an hour on just this function fills you with determination.
            {
                Text = addonName,
                BackColor = Color.FromArgb(15, 15, 66),
                FlatStyle = FlatStyle.Flat,
                FlatAppearance = { BorderSize = 0 },
                Font = new Font("Consolas", 12),
                ForeColor = Color.FromArgb(255, 255, 255),
                TextAlign = ContentAlignment.MiddleLeft,
                Dock = DockStyle.Top,
                Size = new Size(881, 50),
                Padding = new Padding(35, 0, 0, 0)
        };

            myButton.Click += AddonButtonPressHandler; // Adds a function for when the button is clicked/pressed
            addonsList.Controls.Add(myButton); // Adds the button to the list of addons

            return myButton; // Returns the button
        }

        private void ActivateAddonButton_Click(object sender, EventArgs e)
        {
            activateAddonButton.Text = "Activating..."; // Sets the activate button's text to Activating...
            if (selectedAddon is string) // Is the user selecting anything?
            {
                LoadAddon(); // Loads the addon
                MessageBox.Show("Addon loaded successfully!", "GD+ Notification", MessageBoxButtons.OK); // Notifies the user that the addon has been loaded successfully
            }
            activateAddonButton.Text = "Activate"; // Sets the activate button's text to Activate
        }

        private void RemoveAddonButton_Click(object sender, EventArgs e)
        {
            if (selectedAddon is string) // Is the user selecting anything?
            {
                DialogResult result = MessageBox.Show("Are you sure you want to delete this addon?", "GD+ Warning", MessageBoxButtons.YesNo); // Confirms that the user wants to delete the addon
                if (result == DialogResult.Yes) // The user selected yes
                {
                    //Directory.Delete(@"C:\GeometryDashPlus\Addons\" + selectedAddon, true);
                    Directory.Delete(exeUrl + @"\..\..\Addons\" + selectedAddon, true); // Deletes the addon
                    RefreshAddons(); // Refreshes all addons
                }
            }
        }

        private void RenameAddonButton_Click(object sender, EventArgs e)
        {
            if (selectedAddon is string) { // Is the user selecting anything
                string newAddonName = Interaction.InputBox("What will this addon's new name be?", "GD+ Input"); // Prompts the user for the new name of the addon
                //Directory.Move(@"C:\GeometryDashPlus\Addons\" + selectedAddon, @"C:\GeometryDashPlus\Addons\" + newAddonName);
                Directory.Move(exeUrl + @"\..\..\Addons\" + selectedAddon, exeUrl + @"\..\..\Addons\" + newAddonName); // Renames the addon

                selectedAddon = newAddonName; // Changes the selected addon to the new addon's name
                selectedAddonLabel.Text = newAddonName; // Does the same for the label i guess

                RefreshAddons(); // Refreshes all addons
            }
        }

        private void ExplorerAddonButton_Click(object sender, EventArgs e)
        {
            if (selectedAddon is string) // Is the user selecting anything
            {
                //Process.Start(@"C:\GeometryDashPlus\Addons\" + selectedAddon);
                Process.Start(exeUrl + @"\..\..\Addons\" + selectedAddon); // Opens the folder for the addon
            } else
            {
                Process.Start(exeUrl + @"\..\..\Addons\"); // Opens the addons folder
            }
        }

        private void RefreshAddonsButton_Click(object sender, EventArgs e)
        {
            selectedAddon = null; // Deselects the addon
            selectedAddonLabel.Text = "-"; // Updates the label

            RefreshAddons(); // Refreshes all addons
        }
    }
}

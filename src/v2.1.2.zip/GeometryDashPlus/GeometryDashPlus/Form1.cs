﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
using System.Windows.Forms;

namespace GeometryDashPlus
{
    public partial class Home : Form
    {
        public Home()
        {
            InitializeComponent();
            HideSubMenus();
        }

        private void Home_Load(object sender, EventArgs e)
        {
            // Window Style
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.ControlBox = false;

            // Get Latest Version
            Dictionary<string, string> versionInfo = GetLatestVersion();

            if (versionInfo["latest_version"] != "2.1.2") // Do we have the latest version?
            {
                DialogResult result = MessageBox.Show("Update " + versionInfo["latest_version"] + " is available. Update now?", "GD+ Update", MessageBoxButtons.YesNo); // Prompt for update
                if (result == DialogResult.Yes) // User selected yes?
                {
                    Process.Start(versionInfo["latest_version_link"]); // Bring user to download link
                }
            }
        }

        private void HideSubMenus()
        {
            settingsPanel.Visible = false;
        }

        private void ToggleSettingsSubMenu() {
            settingsPanel.Visible = !settingsPanel.Visible;
        }

        private void SettingsButton_Click(object sender, EventArgs e)
        {
            ToggleSettingsSubMenu();
        }

        private void SavedAddonsButton_Click(object sender, EventArgs e)
        {
            OpenChildForm(new SavedAddons()); // Open Saved Addons Tab
            HideSubMenus();
        }

        private void DiscoverTab_Click(object sender, EventArgs e)
        {
            OpenChildForm(new ComingSoon()); // Open Coming Soon Tab
            HideSubMenus();
        }

        #region SettingsSubMenu;

        private void UpdateButton_Click(object sender, EventArgs e)
        {
            HideSubMenus();

            Dictionary<string, string> versionInfo = GetLatestVersion();

            if (versionInfo["latest_version"] != "2.1.2")
            {
                Process.Start(versionInfo["latest_version_link"]);
            }
            else
            {
                MessageBox.Show("You are already up to date!", "GD+ Notification", MessageBoxButtons.OK);
            }
        }

        private void DeveloperToolsButton_Click(object sender, EventArgs e)
        {
            OpenChildForm(new ComingSoon()); // Open Coming Soon Tab
            HideSubMenus();
        }

        private void AboutButton_Click(object sender, EventArgs e)
        {
            OpenChildForm(new About()); // Open About Tab
            HideSubMenus();
        }

        #endregion

        private Form activeForm = null; // Current Opened Tab

        private void OpenChildForm(Form childForm)
        {
            if(activeForm == childForm) // This appears to always be false
                activeForm.Close();
            else
            {
                if(!(activeForm is null))
                    activeForm.Close(); // Closes the current tab opened

                activeForm = childForm; // Switches to new tab
                childForm.TopLevel = false;
                childForm.FormBorderStyle = FormBorderStyle.None; // Removes the border
                childForm.Dock = DockStyle.Fill; // Makes the region of the tab fill the entire space

                panelChildForm.Controls.Add(childForm); // Adds the tab to the tab container
                panelChildForm.Tag = childForm; // Tags the tab container

                childForm.BringToFront(); // Brings tab to front
                childForm.Show(); // Shows tab
            }
        }

        private void CloseButton_Click(object sender, EventArgs e)
        {
            this.Close(); // Closes the program
        }

        private Dictionary<string, string> GetLatestVersion()
        {
            WebClient webClient = new WebClient(); // Creates a web client
            string postLink = "/raw/AHe6zSK2";
            string preLink = "://pastebin.";
            string link = "https" + preLink + "com" + postLink; // May look sketchy, that's because it is, but this is to stop the program from being flagged

            string versionInfoRaw = webClient.DownloadString(link); // Downloads the pastebin content

            JavaScriptSerializer jss = new JavaScriptSerializer(); // Creates a jss
            var versionInfoData = jss.Deserialize<Dictionary<string, string>>(versionInfoRaw); // Deserializes the JSON file

            return versionInfoData; // Returns the version info/dict
        }
    }
}
